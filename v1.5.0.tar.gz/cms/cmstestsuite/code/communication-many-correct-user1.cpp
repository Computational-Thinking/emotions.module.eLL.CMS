int userfunc1(int x) {
    return x;
}
