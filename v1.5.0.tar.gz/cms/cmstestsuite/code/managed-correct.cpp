int userfunc(int x) {
    return x;
}
