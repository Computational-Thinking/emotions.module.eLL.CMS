public static class Batchfileio
{
    public static void Main(string[] args)
    {
        Mmh no, it will not work
    }
}
